-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 29, 2020 at 09:30 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `frank.ly`
--
CREATE DATABASE IF NOT EXISTS `frank.ly` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `frank.ly`;

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `url` varchar(700) NOT NULL,
  `title` varchar(700) NOT NULL,
  `time` varchar(700) NOT NULL,
  `grammar` varchar(100) NOT NULL,
  `abusive` varchar(100) NOT NULL,
  `negative` varchar(100) NOT NULL,
  `neutral` varchar(100) NOT NULL,
  `positive` varchar(100) NOT NULL,
  `distance` varchar(100) NOT NULL,
  `similar` varchar(100) NOT NULL,
  `dissimilar` varchar(100) NOT NULL,
  PRIMARY KEY (`url`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`url`, `title`, `time`, `grammar`, `abusive`, `negative`, `neutral`, `positive`, `distance`, `similar`, `dissimilar`) VALUES
('https://thewire.in/government/14-naxals-killed-in-encounter-in-maharashtra', '14 Naxals Killed in \'Encounter\' in Maharashtra', '22/Apr/2018', '', '', '', '', '', '', '', ''),
('https://thewire.in/government/delhi-police-detains-punjab-youth-congress-chief-for-india-gate-tractor-burning', 'Delhi Police Detains Punjab Youth Congress Chief for India Gate Tractor Burning', '4 hours ago', '', '', '', '', '', '', '', ''),
('https://thewire.in/law/mehbooba-mufti-supreme-court-jammu-and-kashmir-detention', '\'Detention Can\'t Be Forever\': SC Asks J&K Admin to Reply to Plea by Mehbooba Mufti\'s Daughter', '6 hours ago', '46', '0', '', '', '', '', '', ''),
('https://thewire.in/media/sudarshan-news-show-cause-mib-response-upsc-jihad', 'In Response to MIB\'s Show Cause Notice, Sudarshan News Defends \'UPSC Jihad\' Show', '7 hours ago', '33', '0', '8.200000000000001', '84.1', '7.7', '1.5539929657419045', '0', '100'),
('https://thewire.in/politics/at-rs-1034-crore-bjp-richest-national-party-in-fy17-adr-report', 'At Rs 1,034 Crore, BJP Richest National Party in FY17: ADR Report', '10/Apr/2018', '4', '0', '1.7', '90.3', '8.0', '0.651', '56.63', '43.37'),
('https://thewire.in/politics/bihar-polls-upendra-kushwaha-rlsp-rjd-tejashwi-yadav-bsp', 'Bihar: Upendra Kushwaha\'s RLSP Quits RJD-Led Grand Alliance, to Form 3rd Front With BSP', '1 hour ago', '59', '0', '0.0', '97.1', '2.9', '', '', ''),
('https://thewire.in/politics/delhi-bjp-starts-campaign-to-dispel-rumours-among-farmers-about-agriculture-bills', 'Delhi BJP Starts Campaign to Dispel \'Rumours\' Among Farmers About Agriculture Bills', '6 hours ago', '21', '0', '2.1', '87.0', '11.0', '', '', ''),
('https://thewire.in/politics/former-chief-minister-of-assam-anwara-taimur-passed-away', 'Former Chief Minister of Assam Anwara Taimur Passed Away', '7 hours ago', '40', '0', '', '', '', '', '', ''),
('https://thewire.in/politics/sitaram-yechury-re-elected-as-cpim-general-secretary', 'Sitaram Yechury Re-Elected as CPI(M) General Secretary', '22/Apr/2018', '23', '0', '1.2', '90.8', '8.0', '1.571', '0', '100'),
('https://thewire.in/politics/uma-bharti-bjp-jp-nadda-babri-demolition-case', '\'Proud of Role, Will Not Seek Bail\': Accused Uma Bharti to Nadda Ahead of Babri Verdict', '5 hours ago', '57', '0', '5.3', '83.0', '11.7', '1.56', '0', '100'),
('https://thewire.in/politics/will-chirag-paswan-do-to-nitish-kumar-what-his-father-had-done-to-lalu-prasad-in-2005', 'Can Chirag Paswan Do to Nitish Kumar What His Father Had Done to Lalu Prasad in 2005?', '1 hour ago', '', '', '', '', '', '', '', ''),
('https://thewire.in/rights/madhya-pradesh-protests-in-narayanpur-after-man-dies-in-police-custody', 'Madhya Pradesh: Protests in Narayanpur After Man Dies in Police Custody', '7 hours ago', '18', '0', '19.6', '80.4', '0.0', '1.571', '0', '100'),
('https://thewire.in/rights/un-housing-expert-delhi-slum-eviction', 'UN Expert Raises Serious Concerns About Delhi Slum Evictions During COVID-19', '35 minutes ago', '9', '', '', '', '', '', '', ''),
('https://thewire.in/women/sc-states-provide-rations-sex-workers-without-id-proof', 'SC Directs States to Provide Dry Rations to Sex Workers Without Insisting on ID Proof', '2 hours ago', '18', '14', '3.6', '90.3', '6.1', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `user_profile`
--

CREATE TABLE IF NOT EXISTS `user_profile` (
  `user_id` varchar(30) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `dob` varchar(20) NOT NULL,
  `mail_id` varchar(50) NOT NULL,
  `mobile_no` varchar(20) NOT NULL,
  `designation` varchar(50) NOT NULL,
  `password` varchar(300) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_profile`
--

INSERT INTO `user_profile` (`user_id`, `first_name`, `last_name`, `dob`, `mail_id`, `mobile_no`, `designation`, `password`) VALUES
('76', 'do', 'do', 'ei', 'ei', '1', '3 eh', '0000'),
('77', 'sathish', 'raman', '07/07/1999', 'sathishr@gmail.com', '9751769045', 'cse', 'rsr7799'),
('7799', 'SATHISH', 'RAMAN', '07/07/1999', 'sathishrajini2014@gmail.com', '9751769045', 'CSE', 'rsr79'),
('e', '25 win', 'do if', 'Eric is to', 'ei if h', '665', 'gfg', '7'),
('ei', 'ei', 'ei', 'ei', 'ei', '1', 'r', 'g');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
