from selenium import webdriver
import sys

from newspaper import Article

argumentList = sys.argv

del argumentList[0]

string = " ".join(argumentList)

driver = webdriver.Chrome("C:\\Users\\elcot\\Downloads\\chromedriver_win32\\chromedriver.exe")

search_string = string + " site:ndtv.com OR site:indianexpress.com OR site:thehindu.com"

# This is done to structure the string
# into search url.(This can be ignored)
search_string = search_string.replace(' ', '+')

for i in range(1):
    matched_elements = driver.get("https://www.google.com/search?q=" + search_string + "&start=" + str(i))

# driver.get('covid')

ndtv = []
express = []
hindu = []

for a in driver.find_elements_by_xpath('.//a'):
    url = a.get_attribute('href')
    # print(url)
    if ('ndtv.com' in str(url) and 'webcache' not in str(url)) and str(url).count('-') >= 4:
        ndtv.append(str(url))
    if ('thehindu.com' in str(url) and 'webcache' not in str(url)) and str(url).count('-') >= 4:
        hindu.append(str(url))
    if ('indianexpress.com/article' in str(url) and 'webcache' not in str(url) and 'archive' not in str(url)) and str(url).count('-') >= 4:
        express.append(str(url))

driver.close()

# print(ndtv)
# print(express)
# print(hindu)

try:
    if(len(ndtv)>0):
        url = ndtv[0]
    elif(len(express)>0):
        url = express[0]
    else:
        url = hindu[0]

    article = Article(url)
    article.download()
    article.parse()
    var = article.summary

    # print(article.title)
    # print(article.meta_description)
    # print(article.text)
    # print(article.meta_data['keywords'])
    # print(article.meta_data['news_keywords'])

    file1 = open("test.txt", "w", encoding="utf-8")
    file1.write((str(article.text).encode('ascii', 'ignore')).decode('utf-8', 'ignore'))
    file1.close()

except Exception as e:

    print(e)

    print("Error")

    file1 = open("test.txt", "w")
    file1.write("No")
    file1.close()
